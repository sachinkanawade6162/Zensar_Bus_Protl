package com.zensar.bus.exception;

public class PickupPointNotfoundException extends RuntimeException {

}
